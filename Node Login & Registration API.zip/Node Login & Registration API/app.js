const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');

// Importing / Loading User Model
const User = require('./Models/user'); 

const app = express();
const port = process.env.PORT || 3000;

// connecting to MongoDB
mongoose.connect('mongodb://localhost/project', {useNewUrlParser: true});
let db = mongoose.connection;
db.on('error', (err)=> console.log('DB Connection Error: '+err) );
db.once('open' , ()=>console.log('connected to Database...') );

// =========== BodyParser Middleware ====================
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
// parse application/json
app.use(bodyParser.json());


app.get('/' ,(req,res)=>{
    res.send('<a href="http://localhost:3000/api"> API is at http:/localhost:3000/api </a>');
});

app.get('/api', (req,res)=>{
    res.json({message:'wellcome to api'});
});

app.post('/api/login' , (req, res)=>{
  let username = req.body.username ;
  let password = req.body.password ;

  if(!username){
      return res.status(400).json({message:'username is required'}); // bad request
  }

  if(!password){
      return res.status(400).json({message:'password is required'});  // bad request
  }

  if(username && password){
      // getting user info from Database
  User.findOne({username:username , password: password} ,(err , user)=>{
     
    if(err)
     return res.json({message: 'something went wrong.'});
   

    if(!user){
        res.status(404).json({message:'incorrect login details...try again'});
    }
    if(user){
      // creating token and sending as response
      let paylaod = { username : user.username };
      jwt.sign(paylaod , 'secreteKey' , {expiresIn: '120s'} , (err , token)=>{
       if(!err){
           res.json({token: token});
       }
      });

    }
});

  }
 
});

// Dashboard Route which is protected 
app.post('/api/dashboard' , verifyToken , (req,res)=>{
  jwt.verify(req.token , 'secreteKey' , (err, authData)=>{
      if(err){
          res.sendStatus(403) // forbidden 
      } else{
          res.json({message: 'login successfully', authData});
      }
  })
});

// VerifyToken MiddleWare
function verifyToken(req,res , next){
    
    let token = req.headers['authorization'];
    
    if(typeof token !== 'undefined'){
    // save token for next use
      req.token = token;
      next(); // go to next middleware
    } else{
        res.status(403).json({message:'Token is required to get access'}); // forbidden Access
    }
}

// Register a new user
app.post('/api/register' , (req,res)=>{
   if(!req.body.username){
    return res.status(400).send({message: 'username is required'});
   } 

   if(!req.body.password){
     return res.status(400).send({message: 'password is required'});
   } 

   if(req.body.username && req.body.password){
     
    // check wether username already exists in DB or Not
    User.findOne({username:req.body.username} , (err, user)=>{
     if(user){
        return res.json({message:'username already exists'}); // user exists
     } else{
         let newUser = new User();
         newUser.username = req.body.username ,
         newUser.password = req.body.password
         
         newUser.save().then(function(product){
             res.json({message:"New User registered Now"});
         });
     }
    });

   }
});

app.listen(port , ()=>{console.log('server started at port '+port) });